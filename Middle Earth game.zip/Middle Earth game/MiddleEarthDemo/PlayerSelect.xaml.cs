﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MiddleEarthDemo
{
    /// <summary>
    /// Interaction logic for PlayerSelect.xaml
    /// </summary>
    public partial class PlayerSelect : Page
    {
        private GameResources resource = new GameResources();
        private Player myPlayer = new Player();
        private int selected = 0;

        public PlayerSelect()
        {
            InitializeComponent();
        }

        public void GoBackHome(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        public void CycleCharacter(object sender, RoutedEventArgs e)
        {
            var button = (sender as Button).Name;
            int selected = 0;

            if(button == "next")
            {
                selected++;
                if(selected == resource.ReturnDeckSize())
                {
                    selected = 0;

                } 
                
            }    else if(button == "prev")
            {
                selected--;
                if(selected < 0)
                {
                    selected = resource.ReturnDeckSize() - 1;
                }

            }   
            
            myPlayer.UpdateAvatar(new BitmapImage(new Uri(resource.ReturnCharDeck(selected), UriKind.Relative)));
            image.Source = myPlayer.Avatar; 

            myPlayer.UpdateDescription(resource.ReturnCharDesc(selected));
            tblk_charDesc.Text = myPlayer.Description;

            myPlayer.UpdateName(resource.ReturnCharName(selected));
            tblk_charName.Text = myPlayer.Name; 

        }

        public void LoadCharacter(object sender, RoutedEventArgs e)
        {

        }



    }


}
