﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace MiddleEarthDemo
{
    public class Character
    {
        public BitmapImage Avatar { get; protected set; }
        public string Description { get; protected set; }
        public string Name { get; protected set; }


        public void UpdateAvatar(BitmapImage image)
        {
            this.Avatar = image;
        }

        public void UpdateDescription(string description)
        {
            this.Description = description;
        }

        public void UpdateName(string name)
        {
            this.Name = name;
        }

    }
}
