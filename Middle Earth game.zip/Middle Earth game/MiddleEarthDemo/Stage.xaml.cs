﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MiddleEarthDemo
{
    /// <summary>
    /// Interaction logic for Stage.xaml
    /// </summary>
    public partial class Stage : Page
    {
        private Player myPlayer;
        

        public Stage(Player player)
        {
            InitializeComponent();
            myPlayer = player;
            LoadPlayer();
        }

        private void LoadPlayer()
        {
            image.Source = myPlayer.Avatar;
            tblk_charName.Text = myPlayer.Name;
        }


    }
}
