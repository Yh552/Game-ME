﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiddleEarthDemo
{
    public class Player : Character
    {
        private List<string> Inventory = new List<string>()
        {
            "sword",
            "pipe",
            "salted pork"
        };

        public string ShowInventory()
        {
            StringBuilder items = new StringBuilder();
            foreach(string item in Inventory)
            {
                items.Append($"{item}\n"); 
            }
            return items.ToString();    
        }

    }
}
