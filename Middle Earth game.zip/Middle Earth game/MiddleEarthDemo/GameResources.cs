﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiddleEarthDemo
{
    internal class GameResources
    {

        private string[] charDeck = new string[]
        {

            "/images/gandalf.jpg",
            "/images/sauron.jpg",
            "/images/witchKing.jpg",
            "/images/gimli.jpg"
        };

        private string[] charName = new string[]
        {

            "Gandalf the Grey",
            "sauron",
            "Witch-King of Angmar",
            "Gimli"
        };

        private string[] charDesc = new string[]
        {

            " Background on Gandalf the Grey",
            " Background on sauron",
            " Background on Witch-King of Angmar",
            " Background on Glimli"
        };

        //methods
        //Refactor-able

        public string ReturnCharDeck(int i)
        {
            return charDeck[i];

        }

        public string ReturnCharName(int i)
        {
            return charName[i];
        }

        public string ReturnCharDesc(int i)
        {
            return charDesc[i];

        }

        public int ReturnDeckSize()
        {
            return charDeck.Length;
        }

        public int SearchDeck(string s)
        {
            return Array.IndexOf(charDeck, s);
        }







    }
}
